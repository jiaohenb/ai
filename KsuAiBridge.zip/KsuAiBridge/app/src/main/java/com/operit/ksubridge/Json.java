package com.operit.ksubridge;

/** 极简 JSON 工具，避免引入第三方依赖。只做转义与拼装。 */
public final class Json {

    private Json() {}

    public static String esc(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    public static String str(String s) {
        return "\"" + esc(s) + "\"";
    }

    public static String ok(String body) {
        return "{\"ok\":true,\"data\":" + body + "}";
    }

    public static String err(String msg) {
        return "{\"ok\":false,\"error\":" + str(msg) + "}";
    }

    public static String obj(String... kv) {
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(str(kv[i])).append(':').append(kv[i + 1]);
        }
        return sb.append('}').toString();
    }
}
