package com.operit.ksubridge;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;

import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LSPosed entry. Scope must be com.ai.assistance.operit only.
 * Two fallback hook points, either one firing is enough:
 *   1) Instrumentation.callApplicationOnCreate  primary, stable on Android 8~15
 *   2) Application.attach(Context)              fallback
 * AtomicBoolean guarantees the bridge starts once.
 */
public class MainHook implements IXposedHookLoadPackage {

    public static final String TARGET_PKG = "com.ai.assistance.operit";

    private static final AtomicBoolean STARTED = new AtomicBoolean(false);

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) {
            return;
        }

        try {
            XposedHelpers.findAndHookMethod(
                    Instrumentation.class,
                    "callApplicationOnCreate",
                    Application.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Application app = (Application) param.args[0];
                            if (app != null) {
                                startOnce(app, "callApplicationOnCreate");
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("KsuBridge hook#1 failed: " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(
                    Application.class,
                    "attach",
                    Context.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Context ctx = (Context) param.args[0];
                            if (ctx != null) {
                                startOnce(ctx.getApplicationContext(), "Application.attach");
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("KsuBridge hook#2 failed: " + t);
        }
    }

    private static void startOnce(Context ctx, String via) {
        if (ctx == null) {
            return;
        }
        if (!STARTED.compareAndSet(false, true)) {
            return;
        }
        try {
            LocalHttpServer.start(ctx);
            XposedBridge.log("KsuBridge started via " + via);
        } catch (Throwable t) {
            STARTED.set(false);
            XposedBridge.log("KsuBridge start failed via " + via + ": " + t);
        }
    }
}
