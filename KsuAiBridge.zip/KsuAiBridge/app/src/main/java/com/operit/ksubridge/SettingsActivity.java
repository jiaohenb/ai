package com.operit.ksubridge;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** LSPosed 管理器点开模块时显示端口与 token，方便贴进 Operit 工具配置。 */
public class SettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        ll.setPadding(pad, pad, pad, pad);

        TextView tv = new TextView(this);
        tv.setTextSize(13);
        tv.setText(buildText());
        tv.setTextIsSelectable(true);
        ll.addView(tv);

        sv.addView(ll);
        setContentView(sv);
    }

    private String buildText() {
        int port = LocalHttpServer.getPort();
        String token = LocalHttpServer.getToken();
        StringBuilder sb = new StringBuilder();
        sb.append("KSU AI Bridge\n\n");
        sb.append("作用域: com.ai.assistance.operit\n");
        sb.append("状态: ").append(port > 0 ? "服务已启动" : "服务未启动（Operit 未拉起或 hook 未生效）")
                .append("\n\n");
        sb.append("监听: 127.0.0.1:").append(port > 0 ? port : 38888).append("\n");
        sb.append("Token: ").append(token == null ? "(未生成)" : token).append("\n\n");
        sb.append("端点:\n");
        sb.append("GET  /ping\nGET  /status\nGET  /modules\nGET  /superuser\nGET  /feature\n");
        sb.append("POST /module/enable|disable|uninstall|undo|action\n");
        sb.append("POST /module/install\nPOST /root/exec\nPOST /reboot\n\n");
        sb.append("提示: token 首次生成后持久保存，重装模块前请先记录。\n");
        sb.append(String.format(Locale.US, "ksud: %s\n", KsuApi.ksud()));
        return sb.toString();
    }
}
