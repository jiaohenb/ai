package com.operit.ksubridge;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

import de.robv.android.xposed.XposedBridge;

/**
 * 极简本地 HTTP 语义桥。只监听 127.0.0.1，全部请求要求 X-Token。
 * 端口固定 38888，被占用时顺延到 38899。
 * token 持久化在模块自己的 SharedPreferences，首启生成 32 字节随机值。
 *
 * 端点：
 *   GET  /ping
 *   GET  /status
 *   GET  /modules
 *   GET  /superuser
 *   GET  /feature
 *   POST /module/{enable|disable|uninstall|undo|action}   body: {"id":"xxx"}
 *   POST /module/install                                  body: {"path":"/abs/x.zip"}
 *   POST /root/exec                                       body: {"cmd":"...","timeout":30}
 *   POST /reboot                                          body: {"mode":"normal"}
 */
public final class LocalHttpServer {

    private static final int PORT_START = 38888;
    private static final int PORT_END = 38899;
    private static final String PREFS = "ksu_ai_bridge";
    private static final String KEY_TOKEN = "token";

    private static volatile boolean started = false;
    private static volatile ServerSocket server;
    private static volatile String token;

    private LocalHttpServer() {}

    public static synchronized void start(Context ctx) {
        if (started) {
            return;
        }
        started = true;
        token = loadOrCreateToken(ctx);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                bindLoop();
            }
        }, "ksu-ai-bridge");
        t.setDaemon(true);
        t.start();
        XposedBridge.log("KsuBridge listening on 127.0.0.1:" + getPort()
                + " token=" + token);
    }

    private static void bindLoop() {
        for (int port = PORT_START; port <= PORT_END; port++) {
            try {
                ServerSocket ss = new ServerSocket(port, 16,
                        InetAddress.getByName("127.0.0.1"));
                server = ss;
                acceptLoop(ss);
                return;
            } catch (Throwable ignored) {
                // 端口被占，继续下一个
            }
        }
        XposedBridge.log("KsuBridge: no free port in range");
    }

    private static void acceptLoop(ServerSocket ss) {
        while (true) {
            try {
                final Socket s = ss.accept();
                Thread h = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handle(s);
                    }
                });
                h.setDaemon(true);
                h.start();
            } catch (Throwable t) {
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    public static int getPort() {
        ServerSocket s = server;
        return s == null ? -1 : s.getLocalPort();
    }

    public static String getToken() {
        return token;
    }

    private static String loadOrCreateToken(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String t = sp.getString(KEY_TOKEN, null);
            if (t != null && t.length() >= 16) {
                return t;
            }
            byte[] raw = new byte[24];
            new SecureRandom().nextBytes(raw);
            StringBuilder sb = new StringBuilder();
            for (byte b : raw) {
                sb.append(String.format("%02x", b));
            }
            t = sb.toString();
            sp.edit().putString(KEY_TOKEN, t).apply();
            return t;
        } catch (Throwable t) {
            return "fallback-" + System.currentTimeMillis();
        }
    }

    private static void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));

            String requestLine = br.readLine();
            if (requestLine == null || requestLine.isEmpty()) {
                s.close();
                return;
            }

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) {
                respond(s, 400, Json.err("bad request line"));
                return;
            }
            String method = parts[0];
            String path = parts[1];

            String headerToken = null;
            int contentLength = 0;
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                int idx = line.indexOf(':');
                if (idx <= 0) {
                    continue;
                }
                String k = line.substring(0, idx).trim().toLowerCase();
                String v = line.substring(idx + 1).trim();
                if ("x-token".equals(k)) {
                    headerToken = v;
                } else if ("content-length".equals(k)) {
                    try {
                        contentLength = Integer.parseInt(v);
                    } catch (Throwable ignored) {
                    }
                }
            }

            StringBuilder bodyBuf = new StringBuilder();
            if (contentLength > 0 && contentLength < 1 << 20) {
                char[] cb = new char[contentLength];
                int read = 0;
                while (read < contentLength) {
                    int n = br.read(cb, read, contentLength - read);
                    if (n <= 0) {
                        break;
                    }
                    read += n;
                }
                bodyBuf.append(cb, 0, read);
            }
            String body = bodyBuf.toString();

            if (!tokenOk(headerToken)) {
                respond(s, 401, Json.err("invalid token"));
                return;
            }

            String result = route(method, path, body);
            respond(s, 200, result);
        } catch (Throwable t) {
            try {
                respond(s, 500, Json.err(String.valueOf(t)));
            } catch (Throwable ignored) {
            }
        } finally {
            try {
                s.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static boolean tokenOk(String given) {
        String t = token;
        if (t == null || given == null) {
            return false;
        }
        try {
            return MessageDigest.isEqual(
                    t.getBytes(StandardCharsets.UTF_8),
                    given.getBytes(StandardCharsets.UTF_8));
        } catch (Throwable e) {
            return false;
        }
    }

    private static String route(String method, String path, String body) {
        try {
            String p = path;
            int q = p.indexOf('?');
            if (q >= 0) {
                p = p.substring(0, q);
            }

            if ("GET".equals(method)) {
                switch (p) {
                    case "/ping":
                        return Json.ok(Json.obj("pong", "true"));
                    case "/status":
                        return Json.ok(KsuApi.status());
                    case "/modules":
                        return "{\"ok\":true,\"data\":" + KsuApi.modules() + "}";
                    case "/superuser":
                        return "{\"ok\":true,\"data\":" + KsuApi.superuser() + "}";
                    case "/feature":
                        return Json.ok(KsuApi.featureList());
                    default:
                        return Json.err("no route: " + p);
                }
            }

            if ("POST".equals(method)) {
                if (p.startsWith("/module/")) {
                    String op = p.substring("/module/".length());
                    if ("install".equals(op)) {
                        String zip = extract(body, "path");
                        return Json.ok(KsuApi.install(zip));
                    }
                    String id = extract(body, "id");
                    return Json.ok(KsuApi.moduleOp(op, id));
                }
                if ("/root/exec".equals(p)) {
                    String cmd = extract(body, "cmd");
                    if (cmd == null || cmd.trim().isEmpty()) {
                        return Json.err("cmd required");
                    }
                    int timeout = 30;
                    String ts = extractNum(body, "timeout");
                    if (ts != null) {
                        try {
                            timeout = Math.max(1, Math.min(600, Integer.parseInt(ts)));
                        } catch (Throwable ignored) {
                        }
                    }
                    KsuApi.Result r = KsuApi.exec(cmd, timeout);
                    return Json.ok(Json.obj(
                            "code", String.valueOf(r.code),
                            "stdout", Json.str(r.out),
                            "stderr", Json.str(r.err)
                    ));
                }
                if ("/reboot".equals(p)) {
                    String mode = extract(body, "mode");
                    String arg = "normal".equals(mode) || mode == null ? "" : (" " + mode);
                    KsuApi.Result r = KsuApi.exec("reboot" + arg, 10);
                    return Json.ok(Json.obj(
                            "code", String.valueOf(r.code),
                            "mode", Json.str(mode == null ? "normal" : mode)
                    ));
                }
                return Json.err("no route: " + p);
            }

            return Json.err("method not allowed");
        } catch (Throwable t) {
            return Json.err(String.valueOf(t));
        }
    }

    /** 从 JSON body 里抠出字符串字段，够用即可，不追求完整解析。 */
    private static String extract(String body, String key) {
        if (body == null) {
            return null;
        }
        String needle = "\"" + key + "\"";
        int i = body.indexOf(needle);
        if (i < 0) {
            return null;
        }
        int colon = body.indexOf(':', i + needle.length());
        if (colon < 0) {
            return null;
        }
        int start = colon + 1;
        while (start < body.length() && Character.isWhitespace(body.charAt(start))) {
            start++;
        }
        if (start >= body.length()) {
            return null;
        }
        if (body.charAt(start) == '"') {
            StringBuilder sb = new StringBuilder();
            int j = start + 1;
            while (j < body.length()) {
                char c = body.charAt(j);
                if (c == '\\' && j + 1 < body.length()) {
                    char n = body.charAt(j + 1);
                    switch (n) {
                        case 'n': sb.append('\n'); break;
                        case 'r': sb.append('\r'); break;
                        case 't': sb.append('\t'); break;
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case 'u':
                            if (j + 5 < body.length()) {
                                try {
                                    sb.append((char) Integer.parseInt(
                                            body.substring(j + 2, j + 6), 16));
                                    j += 4;
                                } catch (Throwable ignored) {
                                }
                            }
                            break;
                        default: sb.append(n);
                    }
                    j += 2;
                    continue;
                }
                if (c == '"') {
                    break;
                }
                sb.append(c);
                j++;
            }
            return sb.toString();
        }
        int j = start;
        while (j < body.length() && ",}]".indexOf(body.charAt(j)) < 0) {
            j++;
        }
        return body.substring(start, j).trim();
    }

    private static String extractNum(String body, String key) {
        return extract(body, key);
    }

    private static void respond(Socket s, int code, String body) {
        try {
            byte[] payload = body.getBytes(StandardCharsets.UTF_8);
            String head = "HTTP/1.1 " + code + " "
                    + (code == 200 ? "OK" : code == 401 ? "Unauthorized" : "Error")
                    + "\r\nContent-Type: application/json; charset=utf-8\r\n"
                    + "Content-Length: " + payload.length + "\r\n"
                    + "Connection: close\r\n\r\n";
            OutputStream os = s.getOutputStream();
            os.write(head.getBytes(StandardCharsets.UTF_8));
            os.write(payload);
            os.flush();
        } catch (Throwable ignored) {
        }
    }
}
