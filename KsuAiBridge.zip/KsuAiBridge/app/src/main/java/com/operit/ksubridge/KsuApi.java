package com.operit.ksubridge;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * KSU / root 语义封装。
 * 全部通过 su -c 走 KSU 授权执行，模块本身不申请任何特权。
 * ksud 路径优先 /data/adb/ksu/bin/ksud，回退 /data/adb/ksud。
 */
public final class KsuApi {

    private static final String[] KSUD_CANDIDATES = {
            "/data/adb/ksu/bin/ksud",
            "/data/adb/ksud",
            "ksud"
    };

    private static volatile String ksudPath = null;

    public static final class Result {
        public final int code;
        public final String out;
        public final String err;

        Result(int code, String out, String err) {
            this.code = code;
            this.out = out;
            this.err = err;
        }
    }

    private KsuApi() {}

    /** 执行 root 命令。cmd 原样交给 su -c 执行。 */
    public static Result exec(String cmd, int timeoutSec) {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            final Process fp = p;
            final ByteArrayOutputStream outBuf = new ByteArrayOutputStream();
            final ByteArrayOutputStream errBuf = new ByteArrayOutputStream();

            Thread to = pump(fp.getInputStream(), outBuf);
            Thread te = pump(fp.getErrorStream(), errBuf);

            final int[] codeHolder = {-1};
            Thread waiter = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        codeHolder[0] = fp.waitFor();
                    } catch (InterruptedException ignored) {
                    }
                }
            });
            waiter.start();
            waiter.join(Math.max(1, timeoutSec) * 1000L);

            if (waiter.isAlive()) {
                try {
                    fp.destroy();
                } catch (Throwable ignored) {
                }
                return new Result(-9, outBuf.toString("UTF-8"), "timeout after " + timeoutSec + "s");
            }

            to.join(2000);
            te.join(2000);
            return new Result(codeHolder[0],
                    outBuf.toString("UTF-8"), errBuf.toString("UTF-8"));
        } catch (Throwable t) {
            if (p != null) {
                try {
                    p.destroy();
                } catch (Throwable ignored) {
                }
            }
            return new Result(-1, "", String.valueOf(t));
        }
    }

    private static Thread pump(final InputStream in, final ByteArrayOutputStream sink) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buf = new byte[8192];
                int n;
                try {
                    while ((n = in.read(buf)) > 0) {
                        synchronized (sink) {
                            sink.write(buf, 0, n);
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    try {
                        in.close();
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    /** 探测可用的 ksud 路径，结果缓存。 */
    public static synchronized String ksud() {
        if (ksudPath != null) {
            return ksudPath;
        }
        for (String c : KSUD_CANDIDATES) {
            Result r = exec(c + " -V", 8);
            if (r.code == 0 && r.out.toLowerCase().contains("ksud")) {
                ksudPath = c;
                return ksudPath;
            }
        }
        ksudPath = "ksud";
        return ksudPath;
    }

    public static Result ksud(String args, int timeoutSec) {
        return exec(ksud() + " " + args, timeoutSec);
    }

    /** 一次性拉取环境与 KSU 概要状态。 */
    public static String status() {
        String ver = ksud("-V", 10).out.trim();
        String kernel = exec("uname -r", 5).out.trim();
        String susfsVer = ksud("susfs version", 8).out.trim();
        String susfsStat = ksud("susfs status", 8).out.trim();
        String model = exec("getprop ro.product.model", 5).out.trim();
        String release = exec("getprop ro.build.version.release", 5).out.trim();
        String managerVer = exec(
                "dumpsys package com.sukisu.ultra 2>/dev/null | grep -m1 versionName", 8).out.trim();
        boolean root = exec("id -u", 5).out.trim().equals("0");

        return Json.obj(
                "ksud", Json.str(ver),
                "kernel", Json.str(kernel),
                "susfs_version", Json.str(susfsVer),
                "susfs_status", Json.str(susfsStat),
                "model", Json.str(model),
                "android", Json.str(release),
                "manager", Json.str(managerVer),
                "root", root ? "true" : "false"
        );
    }

    /** ksud module list 本身输出 JSON，直接透传。 */
    public static String modules() {
        Result r = ksud("module list", 20);
        if (r.code != 0) {
            return Json.err("ksud module list failed: " + r.err.trim());
        }
        String s = r.out.trim();
        if (s.isEmpty()) {
            return "[]";
        }
        return s;
    }

    public static String moduleOp(String op, String id) {
        if (id == null || id.isEmpty() || !id.matches("[A-Za-z0-9._-]+")) {
            return Json.err("invalid module id");
        }
        Result r;
        switch (op) {
            case "enable":    r = ksud("module enable " + id, 20); break;
            case "disable":   r = ksud("module disable " + id, 20); break;
            case "uninstall": r = ksud("module uninstall " + id, 30); break;
            case "undo":      r = ksud("module undo-uninstall " + id, 20); break;
            case "action":    r = ksud("module action " + id, 60); break;
            default: return Json.err("unknown op: " + op);
        }
        return Json.obj(
                "op", Json.str(op),
                "id", Json.str(id),
                "code", String.valueOf(r.code),
                "stdout", Json.str(r.out.trim()),
                "stderr", Json.str(r.err.trim())
        );
    }

    public static String install(String zipPath) {
        if (zipPath == null || !zipPath.startsWith("/")) {
            return Json.err("zip path must be absolute");
        }
        Result chk = exec("test -f " + shellQuote(zipPath) + " && echo yes", 8);
        if (!chk.out.contains("yes")) {
            return Json.err("zip not found: " + zipPath);
        }
        Result r = ksud("module install " + shellQuote(zipPath), 180);
        return Json.obj(
                "zip", Json.str(zipPath),
                "code", String.valueOf(r.code),
                "stdout", Json.str(r.out.trim()),
                "stderr", Json.str(r.err.trim())
        );
    }

    public static String featureList() {
        Result r = ksud("feature list", 15);
        return Json.obj(
                "code", String.valueOf(r.code),
                "stdout", Json.str(r.out.trim()),
                "stderr", Json.str(r.err.trim())
        );
    }

    /**
     * 解析 /data/adb/ksu/.allowlist。
     * 文件头为 magic USK\177 + version(u32) + count(u32)，条目为
     * 固定长度记录（包名 char 区 + uid u32）。不同 KSU 版本步长略有差异，
     * 这里用启发式扫描：以 0x0C 起始按候选步长逐条提取可打印包名与 uid，
     * 命中数最多且最自洽的步长胜出。读不到时返回空数组而不是报错。
     */
    public static String superuser() {
        Result r = exec(
                "od -An -tx1 -v /data/adb/ksu/.allowlist 2>/dev/null | head -c 200000", 20);
        if (r.code != 0 || r.out.trim().isEmpty()) {
            return "[]";
        }
        byte[] data = hexToBytes(r.out);
        if (data.length < 12) {
            return "[]";
        }
        if ((data[0] & 0xFF) != 0x55 || (data[1] & 0xFF) != 0x53
                || (data[2] & 0xFF) != 0x4B || (data[3] & 0xFF) != 0x7F) {
            return "[]";
        }
        int count = le32(data, 8);
        if (count <= 0 || count > 4096) {
            return "[]";
        }

        int[] candidates = {260, 264, 256, 244, 12036, 12032};
        String best = null;
        int bestScore = -1;

        for (int step : candidates) {
            StringBuilder sb = new StringBuilder("[");
            int hit = 0;
            for (int i = 0; i < count; i++) {
                int off = 12 + i * step;
                if (off + 4 > data.length) {
                    break;
                }
                String name = readCStr(data, off, Math.min(step, 256));
                int uid = -1;
                if (step >= 260 && off + 260 <= data.length) {
                    uid = le32(data, off + 256);
                } else if (off + step <= data.length) {
                    uid = le32(data, off + step - 4);
                }
                boolean okName = name != null && name.matches("[A-Za-z0-9._]+") && name.contains(".");
                boolean okUid = uid >= 0 && uid < 200000;
                if (!okName && !okUid) {
                    continue;
                }
                if (hit > 0) {
                    sb.append(',');
                }
                sb.append(Json.obj(
                        "package", Json.str(name == null ? "" : name),
                        "uid", String.valueOf(uid)
                ));
                hit++;
            }
            sb.append(']');
            int score = hit * 100 - Math.abs(step - 260);
            if (hit > 0 && score > bestScore) {
                bestScore = score;
                best = sb.toString();
            }
        }
        return best == null ? "[]" : best;
    }

    private static String readCStr(byte[] d, int off, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < max && off + i < d.length; i++) {
            int b = d[off + i] & 0xFF;
            if (b == 0) {
                break;
            }
            if (b < 0x20 || b > 0x7E) {
                return null;
            }
            sb.append((char) b);
        }
        return sb.toString();
    }

    private static int le32(byte[] d, int off) {
        if (off + 4 > d.length) {
            return -1;
        }
        return (d[off] & 0xFF)
                | ((d[off + 1] & 0xFF) << 8)
                | ((d[off + 2] & 0xFF) << 16)
                | ((d[off + 3] & 0xFF) << 24);
    }

    private static byte[] hexToBytes(String hex) {
        StringBuilder clean = new StringBuilder(hex.length());
        for (int i = 0; i < hex.length(); i++) {
            char c = hex.charAt(i);
            if (Character.digit(c, 16) >= 0) {
                clean.append(c);
            }
        }
        int len = clean.length() / 2;
        byte[] out = new byte[len];
        for (int i = 0; i < len; i++) {
            out[i] = (byte) ((Character.digit(clean.charAt(i * 2), 16) << 4)
                    | Character.digit(clean.charAt(i * 2 + 1), 16));
        }
        return out;
    }

    public static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    public static String readStream(InputStream in) {
        try {
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    public static void writeAll(OutputStream os, String body) {
        try {
            os.write(body.getBytes(StandardCharsets.UTF_8));
            os.flush();
        } catch (Throwable ignored) {
        }
    }
}
